<template lang="pug">
  div
    template
      mortgage-repayment-calculator(
        ref="children"
        :answers="answers"
        :limit_mortgage_holidays="limit_mortgage_holidays"
        :tooltip_information="tooltip_information"
        :tooltip_holidays="tooltip_holidays"
        :tooltip_early="tooltip_early"
        :tooltip_result="tooltip_result"
        :html_tooltip="html_tooltip"
        :can_share="can_share"
        :calculatorId="calculatorId"
        :answersIdProps="answersIdProps"
        :answerLinkProps="answerLinkProps"
      )

</template>
<script>
const MortgageRepaymentCalculator = () => import ("./MortgageRepaymentCalculator.vue");


export default {
  name: 'MortgageRepaymentEntry',
  data(){
    return {
      array_kind_working:[],
      limit_mortgage_holidays:0,
      tooltip_information: {
        'loan-amount':'',
        'date-receipt':'',
        'bet':'',
        'loan-term':'',
        'annuity-payment':'',
        'differentiated-payment':''
      },
      tooltip_holidays:{
        'beginning-holidays':'',
        'term-holidays':''
      },
      tooltip_early:{
        'early-date':'',
        'early-amount':'',
        'early-frequency':'',
        'early-repetition-period':'',
        'early-what-reduce':''
      },
      tooltip_result:{
        'close-mortgage':'',
        'monthly-payment':'',
        'pay-total':'',
        'savings':''
      },
      html_tooltip:'',
      can_share:0,
      calculatorId:null,
      answersIdProps:null,
      answerLinkProps:null,
      answers: []

    }
  },
  methods:{
  },
  mounted(){
    // if(this.$attrs.limit_holidays!==undefined) {
    //   this.limit_mortgage_holidays=parseInt(this.$attrs.limit_holidays)
    // }

    let limit_holidays = this.$el.getAttribute('limit-holidays')
    if (limit_holidays){
      try{
        this.limit_mortgage_holidays=parseInt(limit_holidays)
      } catch (error) {
        console.log('Ошибка при парсинге');
      }
    }

    let tooltip_information = this.$el.getAttribute('tooltip-information')
    if (tooltip_information){
      try{
        this.tooltip_information = JSON.parse(tooltip_information);
      } catch (error) {
        console.log('Ошибка при парсинге');
      }
    }

    let tooltip_holidays = this.$el.getAttribute('tooltip-holidays')
    if (tooltip_holidays){
      try{
        this.tooltip_holidays = JSON.parse(tooltip_holidays);
      } catch (error) {
        console.log('Ошибка при парсинге');
      }
    }

    let tooltip_early = this.$el.getAttribute('tooltip-early')
    if (tooltip_early){
      try{
        this.tooltip_early = JSON.parse(tooltip_early);
      } catch (error) {
        console.log('Ошибка при парсинге');
      }
    }

    let tooltip_result = this.$el.getAttribute('tooltip-result')
    if (tooltip_result){
      try{
        this.tooltip_result = JSON.parse(tooltip_result);
      } catch (error) {
        console.log('Ошибка при парсинге');
      }
    }

    let html_tooltip = this.$el.getAttribute('html-tooltip')
    if (html_tooltip){
      try{
        this.html_tooltip=html_tooltip
      } catch (error) {
        console.log('Ошибка при парсинге');
      }
    }

    let html_answers = this.$el.getAttribute('answers')
    if (html_answers){
      try{
        this.answers=JSON.parse(html_answers);
      } catch (error) {
        console.log('Ошибка при парсинге');
      }
    }

    let html_can_share = this.$el.getAttribute('answer-can-share')
    if (html_can_share){
      try{
        this.can_share=parseInt(html_can_share)
      } catch (error) {
        console.log('Ошибка при парсинге');
      }
    }

    let html_calculatorId = this.$el.getAttribute('calculatorId')
    if (html_calculatorId){
      try{
        this.calculatorId=parseInt(html_calculatorId)
      } catch (error) {
        console.log('Ошибка при парсинге');
      }
    }

    let html_answersId = this.$el.getAttribute('answersId')
    if (html_answersId){
      try{
        this.answersIdProps=parseInt(html_answersId)
      } catch (error) {
        console.log('Ошибка при парсинге');
      }
    }


    let html_answerLink = this.$el.getAttribute('answers-link')

    if (html_answerLink){
      try{
        this.answerLinkProps=JSON.parse(html_answerLink);
      } catch (error) {
        console.log('Ошибка при парсинге');
      }
    }
    console.log(this.answerLinkProps);
    this.$nextTick(() => {
      setTimeout(()=>{
        this.answers=[]
      },1000)

    })



  },
  computed:{
  },
  watch:{
  },
  components:{
    MortgageRepaymentCalculator
  }
};
</script>
<style scoped>
</style>
