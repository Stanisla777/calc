<template lang="pug">
  .calc-tax-deduc-new__block.calc-tax-deduc-new__area.mor-rep-calculators__block.grey.js--container-block.js-accordion-parent-calc.js--holidays-container-block
    .calc-tax-deduc-new__container-title
      .calc-tax-deduc-new__row-title-container.not-margin
        h3.calc-tax-deduc-new__block-title.mor-rep-calculators__block-title.big(@click="dropdownArea") Ипотечные каникулы
        .content-note.big.js--content-note-open-modal(
            @click="openModal"
            data-modal="mortgage-tip"
          )
        .mor-rep-calculators__alarm(v-show="result_comparing_holidays_early.length>0|| alarm")
        .mor-rep-calculators__folding-block
          .mor-rep-calculators__folding-block-icon
    .calc-tax-deduc-new__wr-function-block.padding.active(@transitionend="handleTransitionEnd")
      .calc-tax-deduc-new__acc-wr
        .calc-tax-deduc-new__block-subtitle
          p Если вы не планируете брать каникулы, можно не заполнять этот блок
        .mor-rep-calculators__body-block
          .calc-tax-deduc-new__row.js--tax-deduc-row
            .calc-tax-deduc-new__row-input.js--calc-row-input
              template
                  component-calendar(
                    :min_date_holidays="min_date_holidays"
                    :max_date="max_date"
                    :loan_term="loan_term"
                    :result_comparing_holidays_early="result_comparing_holidays_early"
                    :tooltip_holidays="tooltip_holidays"
                    :answers="answers"
                    :time_data_loan="time_data_loan"
                    @sendBeginningHolidays="receivedBeginningHolidays"
                    @sendClearHolidayReceive="receivedClearHolidayReceive"
                    @sendAlarm="receivedAlarm"
                  )
              .calc-tax-deduc-new__container-block.mor-rep-calculators__parent-tooltip-mobile.js--container-block.js--tooltip-parent
                .calc-tax-deduc-new__row-title-container
                  p.calc-tax-deduc-new__row-title Срок каникул, мес.
                  span.content-note.content-note__center.desctop.js--content-note(v-if="tooltip_holidays['term-holidays']!==''")
                      span.content-note__text {{tooltip_holidays["term-holidays"]}}
                  span.content-note.mobile(
                    v-if="tooltip_holidays['term-holidays']!==''"
                    @click="openTooltipMobile"
                  )
                div(v-if="tooltip_holidays['term-holidays']!==''")
                  .select__background.modal-special-background(@click="closeTooltipMobile")
                  .select-list__selection-window.modal-special-styles.js--openlist-body
                    .select-list__head
                      p Срок каникул
                      .select-list__head-close(@click="closeTooltipMobile")
                        svg(width='10', height='10', viewbox='0 0 10 10', fill='none', xmlns='http://www.w3.org/2000/svg')
                          path(fill-rule='evenodd', clip-rule='evenodd', d='M0.209209 0.209209C0.488155 -0.0697365 0.940416 -0.0697365 1.21936 0.209209L5 3.98985L8.78064 0.209209C9.05958 -0.0697365 9.51184 -0.0697365 9.79079 0.209209C10.0697 0.488155 10.0697 0.940416 9.79079 1.21936L6.01015 5L9.79079 8.78064C10.0697 9.05958 10.0697 9.51184 9.79079 9.79079C9.51184 10.0697 9.05958 10.0697 8.78064 9.79079L5 6.01015L1.21936 9.79079C0.940416 10.0697 0.488155 10.0697 0.209209 9.79079C-0.0697365 9.51184 -0.0697365 9.05958 0.209209 8.78064L3.98985 5L0.209209 1.21936C-0.0697365 0.940416 -0.0697365 0.488155 0.209209 0.209209Z', fill='#252628')
                    .select-list__wr-search.mor-rep-calculators__wr-search
                      p {{tooltip_holidays["term-holidays"]}}
                .select-list__wrapper.js--select.js--openlist-container.js--only-mobile-fixed.js--for-clear-field.js--for-clear-list-periodicity(ref="selectWrapperTermHoliday")
                  .select__background.modal-special-background.mor-rep-calculators__background-periodicity.js--openlist-background
                  .select__choosen.select__choosen-whith-clear.select__choosen_bordered.js--openlist-btn
                    p.select__substituted-text.input-emty.js--select-option.js-holidays-required Выберите параметр
                    .select__wrap-technical-elements
                      .calc-tax-deduc-new__input-clear.js--clear-calc-tax(
                        @click="clearLoanTerm"
                      )
                      .select__arrow-search
                        svg(width='12', height='8', viewbox='0 0 12 8', fill='none', xmlns='http://www.w3.org/2000/svg')
                          path(fill-rule='evenodd', clip-rule='evenodd', d='M11.753 0.868692C11.9987 1.13419 12.0361 1.58803 11.7904 1.85353L6.50907 7.10074C6.22563 7.40708 5.76607 7.40707 5.48263 7.10074L0.210749 1.84152C-0.0349036 1.57603 -0.000290891 1.13927 0.245361 0.873779C0.491014 0.608285 0.974545 0.608131 1.2202 0.873625L6.00253 5.59224L10.7671 0.868661C11.0127 0.603166 11.5074 0.603198 11.753 0.868692Z', fill='#252628')
                  .select-list__selection-window.mor-rep-calculators__list-periodicity.modal-special-styles.js--openlist-body
                    .select-list__head
                      p Срок каникул, мес
                      .select-list__head-close.js--select-list-close
                        svg(width='10', height='10', viewbox='0 0 10 10', fill='none', xmlns='http://www.w3.org/2000/svg')
                          path(fill-rule='evenodd', clip-rule='evenodd', d='M0.209209 0.209209C0.488155 -0.0697365 0.940416 -0.0697365 1.21936 0.209209L5 3.98985L8.78064 0.209209C9.05958 -0.0697365 9.51184 -0.0697365 9.79079 0.209209C10.0697 0.488155 10.0697 0.940416 9.79079 1.21936L6.01015 5L9.79079 8.78064C10.0697 9.05958 10.0697 9.51184 9.79079 9.79079C9.51184 10.0697 9.05958 10.0697 8.78064 9.79079L5 6.01015L1.21936 9.79079C0.940416 10.0697 0.488155 10.0697 0.209209 9.79079C-0.0697365 9.51184 -0.0697365 9.05958 0.209209 8.78064L3.98985 5L0.209209 1.21936C-0.0697365 0.940416 -0.0697365 0.488155 0.209209 0.209209Z', fill='#252628')
                    .select-list__wr-search
                      .select-list__search-item.js--openlist-item(
                        v-for="item in array_period_holidays"
                        :data-term="item"
                        @click="clickHolidaysTerm"

                      )
                        p {{item}}
                p.mor-rep-calculators__input-error.js--required-error.display-none Это поле обязательное для заполнения

          //кнопка очистить
          .calc-tax-deduc-new__row(v-if="result_comparing_holidays_early.length>0||allFieldsFilled")
            .mor-rep-calculators__row-flex
              .mor-rep-calculators__wrapper-match-warning.js--wrapper-match-warning(v-if="result_comparing_holidays_early.length>0")
                .mor-rep-calculators__match-warning-wr-icon
                  .mor-rep-calculators__match-warning-icon
                .calc-tax-deduc-new__block-subtitle.mor-rep-calculators__match-warning-des
                  p Досрочное пополение во время ипотечных каникул прекращает их действие. Измените дату платежа или параметры каникул

              .mor-rep-calculators__clear-block(
                v-show="allFieldsFilled"
                @click="clearAllFieldBlock"
              )
                .mor-rep-calculators__clear-block-icon
                p Очистить

    //МОДАЛКИ
    //модалка подсказки Ипотечные каникулы, пока не стилизовано
    .modal(ref="dataModal" @click="closeModalBody")
      .modal__wrapper.new.bg-grey.mor-rep-calculators__modal.js--modal
          button.modal__closer.outside(@click="closeModal")
              svg(width='17' height='18' viewBox='0 0 17 18' fill='none' xmlns='http://www.w3.org/2000/svg')
                  path(fill-rule='evenodd' clip-rule='evenodd' d='M0.357542 15.3637C-0.0329827 15.7543 -0.0329827 16.3874 0.357542 16.778C0.748066 17.1685 1.38123 17.1685 1.77176 16.778L8.13551 10.4142L14.4995 16.7782C14.89 17.1687 15.5232 17.1687 15.9137 16.7782C16.3042 16.3876 16.3042 15.7545 15.9137 15.364L9.54972 8.99999L15.9139 2.63582C16.3044 2.24529 16.3044 1.61213 15.9139 1.2216C15.5234 0.83108 14.8902 0.83108 14.4997 1.2216L8.13551 7.58577L1.77156 1.22182C1.38104 0.8313 0.747871 0.8313 0.357346 1.22182C-0.0331781 1.61235 -0.0331778 2.24551 0.357346 2.63604L6.7213 8.99999L0.357542 15.3637Z')

          .modal__main-content.js--modal-main-content(
            v-html="html_tooltip"
          )




            //.feed_back.feedback.modal-new-container
              //p.modal__title Что такое ипотечные каникулы?
              //.mor-rep-calculators__modal-des
                //p Льготный период, в течение которого заёмщик может приостановить выплаты ипотечного кредита.
                //ul
                  //li Заёмщик может приостановить выплаты по ипотечному кредиту на срок до 6 месяцев в рамках льготного периода
                  //li Льготный период может быть применён один раз к кредитам, не превышающим 15 миллионов рублей на момент выдачи
                  //li.
                   //Основанием для ипотечных каникул являются сложные жизненные обстоятельства или чрезвычайные ситуации (подтвердите документально перед обращением в банк)
              //.modal__bottom-sand
                //.btn_s.transparent_black_border.mobile-100 Подробнее





















</template>
<script>
import eventBus from '../development-tools/eventBus.vue';
import Storage from '../development-tools/state.vue';
import componentCalendar from './v-2-component-calendar-holidays.vue';
import numberFormatting from "../mixin/numberFormatting";
// import catalogNew from "../../catalog-new";
export default {
  name: 'v-component-mortgage-holidays',
  mixins: [numberFormatting],
  props:['answers','result_comparing_holidays_early','html_tooltip','tooltip_holidays'],
  data(){
    return {
      array_period_holidays:[1,2,3,4,5,6],
      min_date_holidays: `${new Date().getFullYear() - 30}-01-01`,
      max_date: `${new Date().getFullYear() + 1}-12`,
      loan_term:0,//срок кредита
      term_holiday:0, //срок каникул
      data_holiday:[], //дата каникул

      data_getting_credit:[],
      alarm:false,

      time_data_loan:0
    }
  },
  methods:{
    //стирание
    receivedClearHolidayReceive(){
      this.data_holiday = []

      this.$emit('sendButtonResult')
      this.$emit('sendClearCalendarHolidayAll')
    },
    receivedAlarm(data){
      this.alarm=data
    },

    clearLoanTerm(e) {
      e.stopPropagation();
      this.term_holiday = 0
      const element = e.currentTarget;
      const parent = element.closest('.js--container-block');
      if (parent) {
        const block_input = parent.querySelector('.js--for-clear-field')
        //при клике очистить всё переключение в дефолтное состояние списка переодичность в блоке досрочное погашение
        if (block_input.classList.contains('js--for-clear-list-periodicity')) {
          if (block_input.querySelector('.js--select-option')) {
            block_input.querySelector('.js--select-option').classList.add('input-emty')
            block_input.querySelector('.js--select-option').textContent = 'Выберите параметр'
            if (block_input.querySelector('.js--select-option').classList.contains('js-holidays-required')) {
              block_input.querySelector('.js--select-option').classList.remove('js-filled')
            }
            if (block_input.querySelector('.js--openlist-item.active')) {
              block_input.querySelector('.js--openlist-item.active').classList.remove('active')
            }
          }
        }
      }
      element.classList.remove('active')
      this.$emit('sendButtonResult')
    },



    //очистить все поля блока
    clearAllFieldBlock(el) {
      const element = el.currentTarget
      const parent = element.closest('.js--container-block');
      if (parent) {
        const array_block_input = parent.querySelectorAll('.js--for-clear-field')
        for (let item of array_block_input) {
          //при клике очистить всё переключение в дефолтное состояние списка переодичность в блоке досрочное погашение
          if (item.classList.contains('js--for-clear-list-periodicity')) {
            if (item.querySelector('.js--select-option')) {
              item.querySelector('.js--select-option').classList.add('input-emty')
              item.querySelector('.js--select-option').textContent='Выберите параметр'
              if (item.querySelector('.js--select-option').classList.contains('js-holidays-required')) {
                item.querySelector('.js--select-option').classList.remove('js-filled')
              }

              if (item.querySelector('.js--openlist-item.active')) {
                item.querySelector('.js--openlist-item.active').classList.remove('active')
              }
            }
          }

          //при клике очистить всё очищение поля инпут календаря
          if (item.querySelector('input.js--calendar-field')) {
            item.querySelector('input.js--calendar-field').value = ''
            item.querySelector('input.js--calendar-field').classList.remove('js-filled')
          }
          if (item.querySelector('.js--clear-calc-tax')) {
            item.querySelector('.js--clear-calc-tax').classList.remove('active')
          }
          if (item.closest('.js--container-block') && item.closest('.js--container-block').querySelector('.js--required-error')) {
            item.closest('.js--container-block').querySelector('.js--required-error').classList.add('display-none')
            this.alarm=false
          }
          item.classList.remove('input_error')

          //отправляю в календарь блока
          eventBus.$emit('emitClearCalendarAll')
          this.$emit('sendClearCalendarHolidayAll')



        }
      }
      this.term_holiday=0
      this.data_holiday=[]
      this.$emit('sendButtonResult')
    },











    //открыл модалку с подсказкой
    openModal(el) {
      const element = el.currentTarget
      this.$refs.dataModal.classList.add('open')
      this.AddClassBody()

    },
    closeModal(){
      this.$refs.dataModal.classList.remove('open')
      this.RemoveClassBody()
    },
    closeModalBody(e){
      if(e.target===this.$refs.dataModa){
        this.$refs.dataModalMail.classList.remove('open')
        this.RemoveClassBody()
      }
    },

    //формирую срок каникул
    clickHolidaysTerm(el) {
      const element = el.currentTarget
      const parent = element.closest('.js--select')
      if (parent && parent.querySelector('.js--clear-calc-tax')) {
        parent.querySelector('.js--clear-calc-tax').classList.add('active')
      }
      if (parent && parent.querySelector('.js-holidays-required')) {
        parent.querySelector('.js-holidays-required').classList.add('js-filled')
        this.$emit('sendButtonResult')
      }
      if (parent && parent.closest('.js--container-block')
        && parent.closest('.js--container-block').querySelector('.js--required-error')) {
        parent.closest('.js--container-block').querySelector('.js--required-error').classList.add('display-none')
        this.alarm=false
      }
      if (element.querySelector('p')) {
        this.term_holiday = element.querySelector('p').textContent
        // this.$emit('sendHolidaysTerm',this.term_holiday)
      }
    },
    //получил данные календаря "Начало каникул" и передаю родителю
    receivedBeginningHolidays(data) {
      this.data_holiday=[]
      this.data_holiday = data

      this.$emit('sendClearCalendarHolidayAll')
      this.$emit('sendButtonResult')
    },

  },
  mounted(){

    //подстановка срокаканикул
    if(this.answers.length>0&&this.answers[1] && Object.keys(this.answers[1] || {}).length!==0){
      if(this.answers[1].termHoliday) {
        const term = parseInt(this.answers[1].termHoliday)
        this.$refs.selectWrapperTermHoliday.querySelector(`.js--openlist-item[data-term="${term}"]`).click()
      }

    }

  },
  computed:{
    allFieldsFilled() {
      if (
        this.data_holiday.length!==0 ||
        this.term_holiday !==0
      ) {
        return true
      }
    }
  },

  watch:{
    term_holiday(){
      // console.log('Вотчер this.term_holiday');
      // console.log(this.term_holiday);



    },
    data_holiday(){
      // console.log('this.data_holiday');
      // console.log(this.data_holiday);
    }

  },
  components:{
    componentCalendar

  },
  created(){
  //  Тут помещаюстя Шина событий
    //получил от компоненты "данные об ипотеке" дату получения кредита в виде массива [1, '2025'] и передаю месяц и год в компонент
    // календарь для ипотечных каникул
    eventBus.$on('emitDateLoanReceipt', (data) => {
      this.min_date_holidays = `${data[1]}-${data[0]}`
      this.data_getting_credit = [parseInt(data[0]+1),data[1]]

    })


    //получил от компоненты "данные об ипотеке" срок кредита
    eventBus.$on('emitMonthlyPayment', (data) => {
      this.loan_term=data
    })

    eventBus.$on('emitErrorFieldBlock', (data) => {
      this.alarm=data
    })



    //была нажата кнопка рассчитать
    eventBus.$on('sendtotalCalculation', () => {
      this.$emit('sendHolidaysTerm',this.term_holiday)
      this.$emit('sendBeginningHolidays',this.data_holiday)

    })

    //поучил от данных об ипотеке о том, что поле с латой в нём очистили
    eventBus.$on('emitClearCalendarHolidaysPayment', () => {
      this.min_date_holidays = `${new Date().getFullYear() - 30}-01-01`
    })

    //поучил от данных об ипотеке о том, что поле с латой в нём очистили
    eventBus.$on('emitClearCalendarHolidaysPaymentAll', () => {
      this.min_date_holidays = `${new Date().getFullYear() - 30}-01-01`
      this.loan_term=0
    })

    eventBus.$on('emitTimeDataLoan', (data) => {
      // console.log('Дын дын');
      // console.log(data);
      this.time_data_loan=data
    })

    eventBus.$on('emitClearAllError', () => {
      const parent = this.$el
      if (parent) {
        const array_block_input = parent.querySelectorAll('.js--for-clear-field')
        for (let item of array_block_input) {
          if (item.closest('.js--container-block') && item.closest('.js--container-block').querySelector('.js--required-error')) {
            item.closest('.js--container-block').querySelector('.js--required-error').classList.add('display-none')
            this.alarm=false
          }
          item.classList.remove('input_error')
        }
      }
    })

  }
};
</script>
<style scoped>
</style>
