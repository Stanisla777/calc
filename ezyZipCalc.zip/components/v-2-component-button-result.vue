<template lang="pug">
  button.btn_s.black(
    type="button"
    @click="totalCalculation"
  ) Рассчитать


</template>
<script>
import eventBus from '../development-tools/eventBus.vue';
import Storage from '../development-tools/state.vue';


import numberFormatting from '../mixin/numberFormatting.js';

export default {
  name: 'v-2-component-button-result',
  mixins: [numberFormatting],
  props:[''],
  data(){
    return {

    }
  },
  methods:{
    totalCalculation() {
      //отправляю в компоненты, что была нажата кнопка Рассчитать
      eventBus.$emit('sendtotalCalculation')
      //отправляю в родитель команду
      this.$emit('sendtotalCalculation')

    }




  },
  mounted(){

  },
  computed:{

  },

  watch:{

  },
  components:{

  },
  created(){
  //  Тут помещаюстя Шина событий
  }
};
</script>
<style scoped>
</style>
