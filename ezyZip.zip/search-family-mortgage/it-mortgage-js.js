import dropDown from '../dropDown';

function banksList() {
  // eslint-disable-next-line camelcase
  const btn_more = document.querySelectorAll('.mortgage-surveys__js--btn');
  // eslint-disable-next-line no-empty,camelcase,no-restricted-syntax,no-unused-vars
  for (const item of btn_more) {
    item.onclick = (ev) => {
      const element = ev.currentTarget;
      dropDown(element, 88);
    };
  }
}
export default function itMortgageJs() {
  banksList();
}
