<template lang="pug">
  .mortgage-surveys__final-block-refusal
    p.mortgage-surveys__final-attention.error По техническим причинам сервис временно недоступен.
    .mortgage-surveys__finale-explanation
      p Приносим извинения за неудобства.
      p В случае возникновения вопросов вы можете проконсультироваться по телефону горячей линии Консультационного Центра
        | !{' '}
        a.mortgage-surveys__tele(:href="`tel:${phone}`") {{phone_formatted}}
        | .

</template>
<script>

export default {
  name: 'v-component-failure-not-found',
  props:['phone','phone_formatted'],

};
</script>
<style scoped>
</style>
